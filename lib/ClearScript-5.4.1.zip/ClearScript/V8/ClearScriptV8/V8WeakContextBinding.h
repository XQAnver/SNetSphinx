// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// Microsoft Public License (MS-PL)
// 
// This license governs use of the accompanying software. If you use the
// software, you accept this license. If you do not accept the license, do not
// use the software.
// 
// 1. Definitions
// 
//   The terms "reproduce," "reproduction," "derivative works," and
//   "distribution" have the same meaning here as under U.S. copyright law. A
//   "contribution" is the original software, or any additions or changes to
//   the software. A "contributor" is any person that distributes its
//   contribution under this license. "Licensed patents" are a contributor's
//   patent claims that read directly on its contribution.
// 
// 2. Grant of Rights
// 
//   (A) Copyright Grant- Subject to the terms of this license, including the
//       license conditions and limitations in section 3, each contributor
//       grants you a non-exclusive, worldwide, royalty-free copyright license
//       to reproduce its contribution, prepare derivative works of its
//       contribution, and distribute its contribution or any derivative works
//       that you create.
// 
//   (B) Patent Grant- Subject to the terms of this license, including the
//       license conditions and limitations in section 3, each contributor
//       grants you a non-exclusive, worldwide, royalty-free license under its
//       licensed patents to make, have made, use, sell, offer for sale,
//       import, and/or otherwise dispose of its contribution in the software
//       or derivative works of the contribution in the software.
// 
// 3. Conditions and Limitations
// 
//   (A) No Trademark License- This license does not grant you rights to use
//       any contributors' name, logo, or trademarks.
// 
//   (B) If you bring a patent claim against any contributor over patents that
//       you claim are infringed by the software, your patent license from such
//       contributor to the software ends automatically.
// 
//   (C) If you distribute any portion of the software, you must retain all
//       copyright, patent, trademark, and attribution notices that are present
//       in the software.
// 
//   (D) If you distribute any portion of the software in source code form, you
//       may do so only under this license by including a complete copy of this
//       license with your distribution. If you distribute any portion of the
//       software in compiled or object code form, you may only do so under a
//       license that complies with this license.
// 
//   (E) The software is licensed "as-is." You bear the risk of using it. The
//       contributors give no express warranties, guarantees or conditions. You
//       may have additional consumer rights under your local laws which this
//       license cannot change. To the extent permitted under your local laws,
//       the contributors exclude the implied warranties of merchantability,
//       fitness for a particular purpose and non-infringement.
//       

#pragma once

//-----------------------------------------------------------------------------
// V8WeakContextBinding
//-----------------------------------------------------------------------------

class V8WeakContextBinding: public SharedPtrTarget
{
public:

    V8WeakContextBinding(V8IsolateImpl* pIsolateImpl, V8ContextImpl* pContextImpl):
        m_wrIsolate(pIsolateImpl->CreateWeakRef()),
        m_IsolateName(pIsolateImpl->GetName()),
        m_wrContext(pContextImpl->CreateWeakRef()),
        m_ContextName(pContextImpl->GetName())
    {
    }

    SharedPtr<V8IsolateImpl> GetIsolateImpl() const
    {
        SharedPtr<V8IsolateImpl> spIsolateImpl;
        if (TryGetIsolateImpl(spIsolateImpl))
        {
            return spIsolateImpl;
        }

        throw V8Exception(V8Exception::Type_General, m_IsolateName, StdString(L"The V8 runtime has been destroyed"));
    }

    bool TryGetIsolateImpl(SharedPtr<V8IsolateImpl>& spIsolateImpl) const
    {
        auto spIsolate = m_wrIsolate.GetTarget();
        if (!spIsolate.IsEmpty())
        {
            spIsolateImpl = static_cast<V8IsolateImpl*>(spIsolate.GetRawPtr());
            return true;
        }

        return false;
    }

    SharedPtr<V8ContextImpl> GetContextImpl() const
    {
        SharedPtr<V8ContextImpl> spContextImpl;
        if (TryGetContextImpl(spContextImpl))
        {
            return spContextImpl;
        }

        throw V8Exception(V8Exception::Type_General, m_ContextName, StdString(L"The V8 script engine has been destroyed"));
    }

    bool TryGetContextImpl(SharedPtr<V8ContextImpl>& spContextImpl) const
    {
        auto spContext = m_wrContext.GetTarget();
        if (!spContext.IsEmpty())
        {
            spContextImpl = static_cast<V8ContextImpl*>(spContext.GetRawPtr());
            return true;
        }

        return false;
    }

private:

    WeakRef<V8Isolate> m_wrIsolate;
    StdString m_IsolateName;
    WeakRef<V8Context> m_wrContext;
    StdString m_ContextName;
};
